import React, { useState } from "react";
import { Ocorrencia } from "./src/types/Ocorrencia";
import { ocorrenciasMock } from "./src/data/ocorrenciasMock";
import { ListaScreen } from "./src/screens/ListaScreen";
import { CadastroScreen } from "./src/screens/CadastroScreen";
import { DetalheScreen } from "./src/screens/DetalheScreen";

type Tela = "lista" | "cadastro" | "detalhe";

export default function App() {
  const [tela, setTela] = useState<Tela>("lista");
  const [ocorrencias, setOcorrencias] = useState<Ocorrencia[]>(ocorrenciasMock);
  const [ocorrenciaSelecionada, setOcorrenciaSelecionada] = useState<Ocorrencia | null>(null);

  function handleVerDetalhe(ocorrencia: Ocorrencia) {
    setOcorrenciaSelecionada(ocorrencia);
    setTela("detalhe");
  }

  function handleSalvar(nova: Ocorrencia) {
    setOcorrencias((prev) => [nova, ...prev]);
    setTela("lista");
  }

  const proximoId = ocorrencias.length > 0
    ? Math.max(...ocorrencias.map((o) => o.id)) + 1
    : 1;

  if (tela === "cadastro") {
    return (
      <CadastroScreen
        onSalvar={handleSalvar}
        onVoltar={() => setTela("lista")}
        proximoId={proximoId}
      />
    );
  }

  if (tela === "detalhe" && ocorrenciaSelecionada) {
    return (
      <DetalheScreen
        ocorrencia={ocorrenciaSelecionada}
        onVoltar={() => setTela("lista")}
      />
    );
  }

  return (
    <ListaScreen
      ocorrencias={ocorrencias}
      onVerDetalhe={handleVerDetalhe}
      onNova={() => setTela("cadastro")}
    />
  );
}
