import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { NivelRisco } from "../types/Ocorrencia";

type Props = {
  risco: NivelRisco;
  size?: "sm" | "lg";
};

const CONFIG: Record<NivelRisco, { bg: string; text: string; label: string; icon: string }> = {
  baixo: { bg: "#EAF3DE", text: "#27500A", label: "Risco Baixo", icon: "✓" },
  medio: { bg: "#FAEEDA", text: "#633806", label: "Risco Médio", icon: "!" },
  alto:  { bg: "#FCEBEB", text: "#A32D2D", label: "Risco Alto",  icon: "⚠" },
};

export function RiscoBadge({ risco, size = "sm" }: Props) {
  const c = CONFIG[risco];
  return (
    <View style={[styles.badge, { backgroundColor: c.bg }, size === "lg" && styles.lg]}>
      <Text style={[styles.text, { color: c.text }, size === "lg" && styles.textLg]}>
        {c.icon} {c.label}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 20,
    alignSelf: "flex-start",
  },
  lg: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  text: {
    fontSize: 12,
    fontWeight: "700",
  },
  textLg: {
    fontSize: 14,
  },
});
