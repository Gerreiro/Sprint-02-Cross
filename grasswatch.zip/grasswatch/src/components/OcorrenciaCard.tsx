import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { Ocorrencia, NivelRisco } from "../types/Ocorrencia";

type Props = {
  ocorrencia: Ocorrencia;
  onPress: (ocorrencia: Ocorrencia) => void;
};

const RISCO_CONFIG: Record<NivelRisco, { bg: string; text: string; label: string; icon: string }> = {
  baixo: { bg: "#EAF3DE", text: "#27500A", label: "Baixo", icon: "✓" },
  medio: { bg: "#FAEEDA", text: "#633806", label: "Médio", icon: "!" },
  alto:  { bg: "#FCEBEB", text: "#A32D2D", label: "Alto",  icon: "⚠" },
};

function formatarData(dataStr: string): string {
  const data = new Date(dataStr);
  const hoje = new Date();
  const ontem = new Date();
  ontem.setDate(hoje.getDate() - 1);

  const hora = data.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });

  if (data.toDateString() === hoje.toDateString()) return `Hoje, ${hora}`;
  if (data.toDateString() === ontem.toDateString()) return `Ontem, ${hora}`;
  return data.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
}

export function OcorrenciaCard({ ocorrencia, onPress }: Props) {
  const config = RISCO_CONFIG[ocorrencia.risco];

  return (
    <TouchableOpacity
      style={styles.card}
      onPress={() => onPress(ocorrencia)}
      activeOpacity={0.75}
    >
      <View style={[styles.iconBox, { backgroundColor: config.bg }]}>
        <Text style={[styles.iconText, { color: config.text }]}>{config.icon}</Text>
      </View>

      <View style={styles.info}>
        <Text style={styles.trecho} numberOfLines={1}>
          {ocorrencia.trecho} — {ocorrencia.local}
        </Text>
        <Text style={styles.sub}>
          {formatarData(ocorrencia.data)}
          {ocorrencia.umidadeSensor ? ` · Sensor: ${ocorrencia.umidadeSensor}% umidade` : ""}
        </Text>
      </View>

      <View style={[styles.badge, { backgroundColor: config.bg }]}>
        <Text style={[styles.badgeText, { color: config.text }]}>{config.label}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    borderWidth: 0.5,
    borderColor: "#E0E8E2",
    padding: 12,
    marginBottom: 10,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  iconBox: {
    width: 40,
    height: 40,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  iconText: {
    fontSize: 18,
    fontWeight: "700",
  },
  info: {
    flex: 1,
  },
  trecho: {
    fontSize: 13,
    fontWeight: "600",
    color: "#1A1A1A",
  },
  sub: {
    fontSize: 11,
    color: "#6B7B6E",
    marginTop: 2,
  },
  badge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
  },
  badgeText: {
    fontSize: 11,
    fontWeight: "700",
  },
});
