import React from "react";
import { View, Text, StyleSheet } from "react-native";

type Props = {
  local?: string;
  umidade?: number;
};

export function SensorBanner({ local = "BR-101 km 312", umidade = 82 }: Props) {
  return (
    <View style={styles.banner}>
      <Text style={styles.icon}>📡</Text>
      <View style={styles.textBox}>
        <Text style={styles.title}>Alerta IoT</Text>
        <Text style={styles.sub}>
          Umidade elevada ({umidade}%) — {local}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  banner: {
    backgroundColor: "#FAEEDA",
    borderRadius: 8,
    padding: 12,
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
    borderWidth: 0.5,
    borderColor: "#FAC775",
    borderLeftWidth: 3,
    borderLeftColor: "#EF9F27",
  },
  icon:    { fontSize: 18, marginRight: 10 },
  textBox: { flex: 1 },
  title:   { fontSize: 12, fontWeight: "700", color: "#633806" },
  sub:     { fontSize: 11, color: "#633806", marginTop: 1 },
});
