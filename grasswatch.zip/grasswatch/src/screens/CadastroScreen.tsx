import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  ScrollView,
  Alert,
} from "react-native";
import { Ocorrencia, NivelRisco } from "../types/Ocorrencia";

type Props = {
  onSalvar: (nova: Ocorrencia) => void;
  onVoltar: () => void;
  proximoId: number;
};

export function CadastroScreen({ onSalvar, onVoltar, proximoId }: Props) {
  const [trecho, setTrecho] = useState("");
  const [local, setLocal] = useState("");
  const [descricao, setDescricao] = useState("");
  const [risco, setRisco] = useState<NivelRisco | null>(null);
  const [umidade, setUmidade] = useState("");

  function handleSalvar() {
    if (!trecho.trim()) {
      Alert.alert("Campo obrigatório", "Informe o trecho da rodovia.");
      return;
    }
    if (!local.trim()) {
      Alert.alert("Campo obrigatório", "Informe a localização específica.");
      return;
    }
    if (!risco) {
      Alert.alert("Campo obrigatório", "Selecione o nível de risco.");
      return;
    }

    const nova: Ocorrencia = {
      id: proximoId,
      trecho: trecho.trim(),
      local: local.trim(),
      descricao: descricao.trim() || "Sem descrição.",
      risco,
      data: new Date().toISOString(),
      umidadeSensor: umidade ? Number(umidade) : undefined,
      validadoPorCamera: false,
      status: "pendente",
    };

    onSalvar(nova);
  }

  const RISCOS: { key: NivelRisco; label: string; bg: string; text: string; border: string }[] = [
    { key: "baixo", label: "Baixo", bg: "#EAF3DE", text: "#27500A", border: "#97C459" },
    { key: "medio", label: "Médio", bg: "#FAEEDA", text: "#633806", border: "#EF9F27" },
    { key: "alto",  label: "Alto",  bg: "#FCEBEB", text: "#A32D2D", border: "#E24B4A" },
  ];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#1A3A2E" />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onVoltar}>
          <Text style={styles.back}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Nova ocorrência</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">

        {/* Banner sensor */}
        <View style={styles.banner}>
          <Text style={styles.bannerText}>
            📡 Preencha os dados e confirme visualmente o risco apontado pelo sensor IoT
          </Text>
        </View>

        {/* Trecho */}
        <Text style={styles.label}>Trecho da rodovia *</Text>
        <TextInput
          style={styles.input}
          placeholder="Ex: BR-101 km 312"
          placeholderTextColor="#B0BDB5"
          value={trecho}
          onChangeText={setTrecho}
        />

        {/* Local */}
        <Text style={styles.label}>Localização específica *</Text>
        <TextInput
          style={styles.input}
          placeholder="Ex: Acostamento esquerdo"
          placeholderTextColor="#B0BDB5"
          value={local}
          onChangeText={setLocal}
        />

        {/* Umidade */}
        <Text style={styles.label}>Umidade do sensor IoT (%)</Text>
        <TextInput
          style={styles.input}
          placeholder="Ex: 82"
          placeholderTextColor="#B0BDB5"
          value={umidade}
          onChangeText={setUmidade}
          keyboardType="numeric"
          maxLength={3}
        />

        {/* Risco */}
        <Text style={styles.label}>Classificação de risco *</Text>
        <View style={styles.riscoRow}>
          {RISCOS.map((r) => (
            <TouchableOpacity
              key={r.key}
              style={[
                styles.riscoBtn,
                { backgroundColor: r.bg, borderColor: r.border },
                risco === r.key && styles.riscoBtnSelecionado,
              ]}
              onPress={() => setRisco(r.key)}
            >
              <Text style={[styles.riscoBtnText, { color: r.text }]}>{r.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Descrição */}
        <Text style={styles.label}>Descrição</Text>
        <TextInput
          style={[styles.input, styles.textArea]}
          placeholder="Descreva o estado da vegetação..."
          placeholderTextColor="#B0BDB5"
          value={descricao}
          onChangeText={setDescricao}
          multiline
          numberOfLines={4}
          textAlignVertical="top"
        />

        {/* Botão */}
        <TouchableOpacity style={styles.btn} onPress={handleSalvar}>
          <Text style={styles.btnText}>✓  Registrar ocorrência</Text>
        </TouchableOpacity>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F2F4F3" },
  header: {
    backgroundColor: "#1A3A2E",
    paddingHorizontal: 20,
    paddingVertical: 14,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  back: { color: "#6FCF97", fontSize: 22 },
  headerTitle: { color: "#FFFFFF", fontSize: 17, fontWeight: "600" },
  content: { padding: 16 },
  banner: {
    backgroundColor: "#FAEEDA",
    borderRadius: 8,
    borderWidth: 0.5,
    borderColor: "#FAC775",
    padding: 12,
    marginBottom: 16,
  },
  bannerText: { color: "#633806", fontSize: 12 },
  label: { fontSize: 12, color: "#6B7B6E", fontWeight: "500", marginBottom: 6, marginTop: 4 },
  input: {
    backgroundColor: "#FFFFFF",
    borderRadius: 8,
    borderWidth: 0.5,
    borderColor: "#D1D9D3",
    paddingHorizontal: 12,
    paddingVertical: 11,
    fontSize: 14,
    color: "#1A1A1A",
    marginBottom: 14,
  },
  textArea: { height: 96, marginBottom: 14 },
  riscoRow: { flexDirection: "row", gap: 8, marginBottom: 14 },
  riscoBtn: {
    flex: 1,
    paddingVertical: 11,
    borderRadius: 8,
    borderWidth: 1.5,
    alignItems: "center",
  },
  riscoBtnSelecionado: {
    borderWidth: 2.5,
    shadowColor: "#1D9E75",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 4,
    elevation: 3,
  },
  riscoBtnText: { fontSize: 13, fontWeight: "700" },
  btn: {
    backgroundColor: "#1A3A2E",
    borderRadius: 12,
    paddingVertical: 15,
    alignItems: "center",
    marginTop: 8,
  },
  btnText: { color: "#FFFFFF", fontSize: 15, fontWeight: "600" },
});
