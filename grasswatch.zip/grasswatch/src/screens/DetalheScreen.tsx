import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  ScrollView,
} from "react-native";
import { Ocorrencia } from "../types/Ocorrencia";
import { RiscoBadge } from "../components/RiscoBadge";

type Props = {
  ocorrencia: Ocorrencia;
  onVoltar: () => void;
};

const STATUS_CONFIG = {
  pendente:      { label: "Pendente",         color: "#A32D2D", bg: "#FCEBEB" },
  em_andamento:  { label: "Em andamento",     color: "#854F0B", bg: "#FAEEDA" },
  resolvido:     { label: "Resolvido ✓",      color: "#27500A", bg: "#EAF3DE" },
};

function formatarDataCompleta(dataStr: string): string {
  const d = new Date(dataStr);
  return d.toLocaleString("pt-BR", {
    day: "2-digit", month: "2-digit", year: "numeric",
    hour: "2-digit", minute: "2-digit",
  });
}

export function DetalheScreen({ ocorrencia, onVoltar }: Props) {
  const statusCfg = STATUS_CONFIG[ocorrencia.status];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#1A3A2E" />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onVoltar}>
          <Text style={styles.back}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Detalhe</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>

        {/* Foto placeholder */}
        <View style={styles.foto}>
          <Text style={styles.fotoIcon}>🖼</Text>
          <Text style={styles.fotoLabel}>
            {ocorrencia.validadoPorCamera ? "Foto registrada ✓" : "Sem foto"}
          </Text>
        </View>

        {/* Título + badge */}
        <View style={styles.tituloRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.titulo}>{ocorrencia.trecho}</Text>
            <Text style={styles.sub}>{ocorrencia.local}</Text>
          </View>
          <RiscoBadge risco={ocorrencia.risco} size="lg" />
        </View>

        {/* Sensor IoT */}
        {ocorrencia.umidadeSensor !== undefined && (
          <>
            <Text style={styles.sectionLabel}>DADOS DO SENSOR IOT</Text>
            <View style={styles.sensorCard}>
              <Text style={styles.sensorIcon}>💧</Text>
              <View>
                <Text style={styles.sensorVal}>{ocorrencia.umidadeSensor}%</Text>
                <Text style={styles.sensorSub}>Umidade do solo</Text>
              </View>
              <View style={{ marginLeft: "auto", alignItems: "flex-end" }}>
                <Text style={styles.sensorStatus}>
                  {ocorrencia.validadoPorCamera ? "Confirmado por câmera" : "Aguardando validação"}
                </Text>
                <Text style={styles.sensorCam}>
                  {ocorrencia.validadoPorCamera ? "via câmera ✓" : "câmera ✗"}
                </Text>
              </View>
            </View>
          </>
        )}

        {/* Informações */}
        <Text style={styles.sectionLabel}>INFORMAÇÕES</Text>
        <View style={styles.infoCard}>
          <InfoRow label="Registrado em" value={formatarDataCompleta(ocorrencia.data)} />
          <InfoRow
            label="Status"
            value={statusCfg.label}
            valueStyle={{ color: statusCfg.color, fontWeight: "700" }}
          />
          <InfoRow
            label="Validado por câmera"
            value={ocorrencia.validadoPorCamera ? "Sim ✓" : "Não"}
            valueStyle={{ color: ocorrencia.validadoPorCamera ? "#27500A" : "#A32D2D" }}
          />
          <InfoRow label="ID da ocorrência" value={`#${ocorrencia.id}`} last />
        </View>

        {/* Descrição */}
        <Text style={styles.sectionLabel}>DESCRIÇÃO</Text>
        <View style={styles.descCard}>
          <Text style={styles.desc}>{ocorrencia.descricao}</Text>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

function InfoRow({
  label,
  value,
  valueStyle,
  last,
}: {
  label: string;
  value: string;
  valueStyle?: object;
  last?: boolean;
}) {
  return (
    <View style={[styles.infoRow, !last && styles.infoRowBorder]}>
      <Text style={styles.infoLabel}>{label}</Text>
      <Text style={[styles.infoValue, valueStyle]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F2F4F3" },
  header: {
    backgroundColor: "#1A3A2E",
    paddingHorizontal: 20,
    paddingVertical: 14,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  back: { color: "#6FCF97", fontSize: 22 },
  headerTitle: { color: "#FFFFFF", fontSize: 17, fontWeight: "600" },
  content: { padding: 16 },
  foto: {
    borderRadius: 12,
    height: 160,
    backgroundColor: "#1A3A2E",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 16,
  },
  fotoIcon: { fontSize: 40, opacity: 0.4 },
  fotoLabel: { color: "rgba(255,255,255,0.5)", fontSize: 12, marginTop: 6 },
  tituloRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 20,
    gap: 10,
  },
  titulo: { fontSize: 17, fontWeight: "700", color: "#1A1A1A" },
  sub: { fontSize: 13, color: "#6B7B6E", marginTop: 2 },
  sectionLabel: {
    fontSize: 11,
    fontWeight: "700",
    color: "#9BA8A0",
    letterSpacing: 0.8,
    marginBottom: 8,
    marginTop: 4,
  },
  sensorCard: {
    backgroundColor: "#EAF3DE",
    borderRadius: 10,
    padding: 14,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 20,
  },
  sensorIcon: { fontSize: 22 },
  sensorVal: { fontSize: 22, fontWeight: "700", color: "#27500A" },
  sensorSub: { fontSize: 11, color: "#639922" },
  sensorStatus: { fontSize: 12, fontWeight: "600", color: "#3B6D11" },
  sensorCam: { fontSize: 11, color: "#9BA8A0" },
  infoCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 10,
    borderWidth: 0.5,
    borderColor: "#E0E8E2",
    paddingHorizontal: 14,
    marginBottom: 20,
  },
  infoRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 12, alignItems: "center" },
  infoRowBorder: { borderBottomWidth: 0.5, borderBottomColor: "#F0F2F0" },
  infoLabel: { fontSize: 13, color: "#6B7B6E" },
  infoValue: { fontSize: 13, fontWeight: "600", color: "#1A1A1A", flex: 1, textAlign: "right" },
  descCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 10,
    borderWidth: 0.5,
    borderColor: "#E0E8E2",
    padding: 14,
    marginBottom: 20,
  },
  desc: { fontSize: 14, color: "#1A1A1A", lineHeight: 22 },
});
