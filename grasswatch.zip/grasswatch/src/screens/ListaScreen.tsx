import React, { useState } from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
} from "react-native";
import { Ocorrencia, NivelRisco } from "../types/Ocorrencia";
import { OcorrenciaCard } from "../components/OcorrenciaCard";

type Filtro = "todas" | NivelRisco;

type Props = {
  ocorrencias: Ocorrencia[];
  onVerDetalhe: (ocorrencia: Ocorrencia) => void;
  onNova: () => void;
};

export function ListaScreen({ ocorrencias, onVerDetalhe, onNova }: Props) {
  const [filtro, setFiltro] = useState<Filtro>("todas");

  const listaFiltrada =
    filtro === "todas"
      ? ocorrencias
      : ocorrencias.filter((o) => o.risco === filtro);

  const temAlertaIoT = ocorrencias.some(
    (o) => o.risco === "alto" && o.umidadeSensor && o.umidadeSensor > 75
  );
  const alertaOcorrencia = ocorrencias.find(
    (o) => o.risco === "alto" && o.umidadeSensor && o.umidadeSensor > 75
  );

  const FILTROS: { key: Filtro; label: string }[] = [
    { key: "todas", label: "Todas" },
    { key: "alto",  label: "Alto" },
    { key: "medio", label: "Médio" },
    { key: "baixo", label: "Baixo" },
  ];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#1A3A2E" />

      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>🌿 Ocorrências</Text>
        <TouchableOpacity style={styles.addBtn} onPress={onNova}>
          <Text style={styles.addBtnText}>+</Text>
        </TouchableOpacity>
      </View>

      {/* Filtros */}
      <View style={styles.filtrosRow}>
        {FILTROS.map((f) => (
          <TouchableOpacity
            key={f.key}
            style={[styles.filtroBtn, filtro === f.key && styles.filtroBtnAtivo]}
            onPress={() => setFiltro(f.key)}
          >
            <Text style={[styles.filtroText, filtro === f.key && styles.filtroTextAtivo]}>
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Banner IoT */}
      {temAlertaIoT && alertaOcorrencia && (
        <View style={styles.banner}>
          <Text style={styles.bannerText}>
            ⚠ Alerta IoT: Umidade elevada ({alertaOcorrencia.umidadeSensor}%) — {alertaOcorrencia.trecho}
          </Text>
        </View>
      )}

      {/* Lista */}
      <FlatList
        data={listaFiltrada}
        keyExtractor={(item) => String(item.id)}
        renderItem={({ item }) => (
          <OcorrenciaCard ocorrencia={item} onPress={onVerDetalhe} />
        )}
        contentContainerStyle={styles.lista}
        ListEmptyComponent={
          <View style={styles.vazio}>
            <Text style={styles.vazioText}>Nenhuma ocorrência encontrada.</Text>
          </View>
        }
        ListFooterComponent={
          listaFiltrada.length > 0 ? (
            <Text style={styles.contador}>
              {listaFiltrada.length} ocorrência{listaFiltrada.length !== 1 ? "s" : ""}
            </Text>
          ) : null
        }
      />

      {/* FAB */}
      <TouchableOpacity style={styles.fab} onPress={onNova}>
        <Text style={styles.fabText}>+</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F2F4F3" },
  header: {
    backgroundColor: "#1A3A2E",
    paddingHorizontal: 20,
    paddingVertical: 14,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerTitle: { color: "#FFFFFF", fontSize: 18, fontWeight: "700" },
  addBtn: {
    backgroundColor: "#1D9E75",
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  addBtnText: { color: "#FFF", fontSize: 22, lineHeight: 28, fontWeight: "300" },
  filtrosRow: {
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingVertical: 10,
    gap: 8,
    backgroundColor: "#F2F4F3",
  },
  filtroBtn: {
    flex: 1,
    paddingVertical: 7,
    borderRadius: 8,
    backgroundColor: "#E8EDE9",
    alignItems: "center",
  },
  filtroBtnAtivo: { backgroundColor: "#1A3A2E" },
  filtroText: { fontSize: 12, color: "#6B7B6E", fontWeight: "500" },
  filtroTextAtivo: { color: "#FFFFFF", fontWeight: "700" },
  banner: {
    marginHorizontal: 16,
    marginBottom: 6,
    backgroundColor: "#FAEEDA",
    borderRadius: 8,
    borderWidth: 0.5,
    borderColor: "#FAC775",
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  bannerText: { color: "#633806", fontSize: 12, fontWeight: "500" },
  lista: { paddingHorizontal: 16, paddingBottom: 100, paddingTop: 4 },
  vazio: { alignItems: "center", paddingTop: 60 },
  vazioText: { color: "#9BA8A0", fontSize: 14 },
  contador: { textAlign: "center", color: "#9BA8A0", fontSize: 12, paddingTop: 8 },
  fab: {
    position: "absolute",
    bottom: 28,
    right: 20,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: "#1D9E75",
    alignItems: "center",
    justifyContent: "center",
    elevation: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  fabText: { color: "#FFF", fontSize: 28, fontWeight: "300", lineHeight: 34 },
});
